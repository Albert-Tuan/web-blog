---
name: Nhật Ký Lập Trình
colors:
  surface: '#fff8f3'
  surface-dim: '#e7d8c2'
  surface-bright: '#fff8f3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff2e0'
  surface-container: '#fcecd6'
  surface-container-high: '#f6e6d0'
  surface-container-highest: '#f0e0cb'
  on-surface: '#221a0d'
  on-surface-variant: '#4e4637'
  inverse-surface: '#382f20'
  inverse-on-surface: '#feefd8'
  outline: '#807665'
  outline-variant: '#d1c5b2'
  surface-tint: '#795900'
  primary: '#6f5100'
  on-primary: '#ffffff'
  primary-container: '#8b6914'
  on-primary-container: '#fff0da'
  inverse-primary: '#ecc165'
  secondary: '#43682b'
  on-secondary: '#ffffff'
  secondary-container: '#c1eca1'
  on-secondary-container: '#476c2f'
  tertiary: '#9c310b'
  on-tertiary: '#ffffff'
  tertiary-container: '#bd4823'
  on-tertiary-container: '#ffeeea'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdfa0'
  primary-fixed-dim: '#ecc165'
  on-primary-fixed: '#261a00'
  on-primary-fixed-variant: '#5c4300'
  secondary-fixed: '#c4efa3'
  secondary-fixed-dim: '#a8d38a'
  on-secondary-fixed: '#0a2100'
  on-secondary-fixed-variant: '#2c4f15'
  tertiary-fixed: '#ffdbd1'
  tertiary-fixed-dim: '#ffb59f'
  on-tertiary-fixed: '#3a0a00'
  on-tertiary-fixed-variant: '#852300'
  background: '#fff8f3'
  on-background: '#221a0d'
  surface-variant: '#f0e0cb'
typography:
  headline-xl:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Newsreader
    fontSize: 20px
    fontWeight: '400'
    lineHeight: 32px
  body-md:
    fontFamily: Newsreader
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 28px
  body-sm:
    fontFamily: Newsreader
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  label-lg:
    fontFamily: Courier Prime
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-md:
    fontFamily: Courier Prime
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.03em
  label-sm:
    fontFamily: Courier Prime
    fontSize: 10px
    fontWeight: '400'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes an intimate, tactile developer journal. Rooted in the visual metaphor of a well-worn leather-bound notebook and hand-kept bullet journal, it blends technical rigor with literary warmth. 

The aesthetic draws on tactile skeuomorphism and classical editorial bookcraft: parchment tones, ruled lines, stitch marks, ink-stamp accents, and considered typographic contrast. Rather than simulating flat digital dashboards, interface surfaces feel printed, pressed, or bound.

The audience consists of thoughtful engineers, writers, and technical craftspeople who value deliberate documentation, long-form reflection, and personal progress logs.

## Colors

The palette is derived from classic bookbinding materials and writing instruments:

- **Primary (`#8B6914`):** Rich leather ochre and burnished brass. Used for prominent section headings, active states, key interactive indicators, and primary callouts.
- **Secondary (`#2D5016`):** Forest ink stamp green. Denotes verified tags, successful compilation indicators, progress bullets, and botanical marginalia.
- **Tertiary (`#8B2500`):** Crimson sealing wax and red correction ink. Reserved for bookmark ribbons, alerts, important highlights, and callout badges.
- **Neutral (`#2C2416`):** Deep iron-gall ink. Delivers primary legibility for long-form reading, replacing synthetic pure black with organic carbon warmth.
- **Canvas & Paper Tiers:** Backgrounds transition across warm parchment (`#FDF5E6`), pressed interior card stock (`#FAF8F5`), and aged page edges (`#F5E6D3`).
- **Rule Lines & Stitching (`#D4A574`):** Warm sepia thread used for borders, dot matrices, and notebook page rulings.

## Typography

Typography maintains a deliberate hierarchy between published literary prose, technical notations, and editorial headings:

- **Display & Headlines (Playfair Display):** Conveys the permanence and dignity of traditional book covers and chapter titles. Used with tight letter-spacing and generous vertical breathing room.
- **Body & Longform Reading (Newsreader):** Optimized for continuous reading comfort. Features proportional serifs and warm stroke contrast suited for extensive prose, narrative code post-mortems, and engineering journals.
- **Metadata & Technical Notation (Courier Prime):** Employs typewriter-style monospacing for metadata, timestamps, tags, code snippets, and commit hashes, grounding the literary system in software craft.

## Layout & Spacing

The layout is built upon an editorial grid with comfortable line lengths for reading. 

- **Grid Model:** A desktop 12-column grid with a maximum content container width of `1120px` to mirror physical book spreads. Articles and longform reading are constrained to a focused central column of `720px` (approx. 65–75 characters per line).
- **Margins & Gutters:** Generous gutters replicate notebook margins, allowing annotations, line numbers, and stamp badges to sit in the periphery without overcrowding prose.
- **Rhythmic Vertical Alignments:** Spacing follows a baseline multiplier that aligns with physical ruled paper heights (`28px`), giving structure to paragraph blocks, code snippets, and marginal notes.

## Elevation & Depth

Visual hierarchy rejects harsh digital drop shadows in favor of paper layering and ambient ink depth:

- **Layer 0 (Canvas):** The warm desk and cover surface (`#FDF5E6`), textured with a faint dot grid pattern or linen cast.
- **Layer 1 (Card & Page):** Clean paper sheets (`#FAF8F5`) elevated with soft, warm-tinted ambient diffuse shadows (`0 2px 8px rgba(44, 36, 22, 0.06), 0 1px 2px rgba(44, 36, 22, 0.04)`).
- **Layer 2 (Overlays & Sticky Elements):** Bookmarks, floating note tabs, and popovers cast slightly deeper bookish shadows (`0 8px 24px rgba(44, 36, 22, 0.10), 0 2px 6px rgba(44, 36, 22, 0.05)`).
- **Structural Outlines:** Subtle double borders or dashed stitch lines (`1px dashed #D4A574`) establish component edges rather than thick solid strokes.

## Shapes

The design system uses a subtle soft-corner language (`roundedness: 1`), giving components a radius of `0.25rem` (`4px`). This mimics the gentle wear on the corners of trimmed paper stock and notebook leaves.

Cards and large panels utilize `rounded-lg` (`0.5rem` / `8px`) to evoke rigid leather or chipboard covers. Circular shapes are strictly reserved for bullet markers, verification stamps, and small bookmark pins.

## Components

- **Buttons:** Styled like pressed linen labels or wax-stamp seals. Primary buttons feature `#8B6914` leather fill, `#FAF8F5` text, and a fine `1px` border ring. Secondary buttons use transparent parchment with a `#D4A574` dashed or solid ruled border. Hover states introduce a warm ink press effect (subtle downward translation of `1px`).
- **Cards & Page Containers:** Constructed on `#FAF8F5` surfaces with a subtle `#D4A574` single or double outline. Optional left-side spine border simulating binder rings or bound cloth stitching.
- **Bullet Journal Checkboxes & Markers:** Custom SVG checkboxes rendered as hand-inked square outlines. Checked states display an ink cross (`×`) or filled bullet (`▪`) in `#2D5016` or `#8B6914`.
- **Washi Tape & Labels:** Metadata chips and tags feature flat rectangular silhouettes with asymmetrical or scalloped vertical edges, translucent parchment fills (`rgba(212, 165, 116, 0.25)`), and monospaced text in `#2C2416`.
- **Code Blocks:** Framed as glued-in engineer slips on an aged paper background (`#F5E6D3`), featuring a left gutter ruled with vintage line numbers in `#8B6914` and Courier typography.
- **Dividers & Ruled Guides:** Horizontal rules alternate between thin solid guides (`1px solid #D4A574`), stitched dashes (`1px dashed #D4A574`), and classic ornamental central flourishes (`§` or `❖`).
- **Inputs & Form Fields:** Clean, single underline fields styled like printed journal fill-in blanks (`border-bottom: 1.5px solid #D4A574`), shifting to `#8B6914` on focus with no glowing halos.